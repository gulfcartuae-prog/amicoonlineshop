/**
 * AMICO Online Shop - Cart Management & Slide-Out Drawer
 * Real-time synchronization with Shopify Cart API, UAE express delivery & micro-animations
 */

const Cart = {
  items: [],
  shopifyCartId: null,
  isDrawerOpen: false,

  init() {
    this.loadFromStorage();
    this.bindEvents();
    this.updateBadge();
    this.renderDrawer();
    if (document.getElementById('cart-page-container')) {
      this.renderCartPage();
    }
    this.syncWithCatalog();
  },

  /**
   * When Shopify is connected, refresh saved cart lines from the live catalog so
   * a price/photo change made in Shopify shows up in a bag that was filled earlier.
   * Lines whose product no longer exists in Shopify are dropped (checkout would fail).
   */
  async syncWithCatalog() {
    if (!this.items.length || !window.ProductsCatalog) return;
    await window.ProductsCatalog.whenReady();
    if (window.ProductsCatalog.source !== 'shopify') return;

    const catalog = window.ProductsCatalog;
    let removed = 0;
    this.items = this.items.filter(item => {
      const p = catalog.findByIdOrHandle(item.productId);
      const v = p && catalog.resolveVariant(p, item.size, item.color);
      if (!p || !v) { removed++; return false; }
      item.variantId = v.id;
      item.price = v.price || p.price;
      item.image = p.image || item.image;
      item.title = p.title;
      return true;
    });

    this.saveToStorage();
    this.updateBadge();
    this.renderDrawer();
    if (document.getElementById('cart-page-container')) this.renderCartPage();
    if (removed) this.showToast('Some items in your bag are no longer available and were removed');
  },

  loadFromStorage() {
    try {
      const stored = localStorage.getItem('amico_cart');
      if (stored) {
        this.items = JSON.parse(stored);
      }
      this.shopifyCartId = localStorage.getItem('amico_shopify_cart_id') || null;
    } catch (e) {
      console.warn('Could not read cart from localStorage', e);
      this.items = [];
    }
  },

  saveToStorage() {
    try {
      localStorage.setItem('amico_cart', JSON.stringify(this.items));
      if (this.shopifyCartId) {
        localStorage.setItem('amico_shopify_cart_id', this.shopifyCartId);
      }
    } catch (e) {
      console.warn('Could not write cart to localStorage', e);
    }
  },

  generateKey(productId, size = '', color = '') {
    return `${productId}_${size}_${color}`.toLowerCase();
  },

  async addItem({ productId, variantId, title, price, image, size = '', color = '', quantity = 1, category = '' }) {
    const key = this.generateKey(productId, size, color);
    const existingIndex = this.items.findIndex(item => item.key === key);

    if (existingIndex > -1) {
      this.items[existingIndex].quantity += quantity;
    } else {
      this.items.push({
        key,
        productId,
        variantId,
        title,
        price: parseFloat(price),
        image,
        size,
        color,
        category,
        quantity
      });
    }

    this.saveToStorage();
    this.updateBadge(true); // with animation
    this.renderDrawer();
    if (document.getElementById('cart-page-container')) {
      this.renderCartPage();
    }

    // Sync with Shopify Cart API in background if configured
    if (window.shopify?.isLiveConfigured && variantId) {
      try {
        if (!this.shopifyCartId) {
          const cart = await window.shopify.cartCreate([{ merchandiseId: variantId, quantity }]);
          this.shopifyCartId = cart.id;
          this.saveToStorage();
        } else {
          await window.shopify.cartLinesAdd(this.shopifyCartId, [{ merchandiseId: variantId, quantity }]);
        }
      } catch (err) {
        console.warn('Shopify Cart Sync notice:', err.message);
      }
    }

    this.openDrawer();
    // The drawer itself confirms the add. Only toast when there is no drawer on the page
    // (on phones the toast sat on top of the "View Full Bag" button).
    if (!document.getElementById('cart-drawer')) {
      this.showToast(`Added "${title}" to your shopping bag`);
    }
  },

  async updateQuantity(key, quantity) {
    const target = this.items.find(item => item.key === key);
    if (!target) return;

    if (quantity <= 0) {
      await this.removeItem(key);
      return;
    }

    target.quantity = quantity;
    this.saveToStorage();
    this.updateBadge();
    this.renderDrawer();
    if (document.getElementById('cart-page-container')) {
      this.renderCartPage();
    }
  },

  async removeItem(key) {
    const item = this.items.find(i => i.key === key);
    this.items = this.items.filter(i => i.key !== key);
    this.saveToStorage();
    this.updateBadge();
    this.renderDrawer();
    if (document.getElementById('cart-page-container')) {
      this.renderCartPage();
    }
    if (item) {
      this.showToast(`Removed "${item.title}"`);
    }
  },

  clear() {
    this.items = [];
    this.saveToStorage();
    this.updateBadge();
    this.renderDrawer();
    if (document.getElementById('cart-page-container')) {
      this.renderCartPage();
    }
  },

  getTotals() {
    const subtotal = this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const freeShippingThreshold = window.CONFIG?.SHIPPING?.FREE_SHIPPING_THRESHOLD || 250;
    const isFreeShipping = subtotal >= freeShippingThreshold || this.items.length === 0;
    const shippingFee = isFreeShipping ? 0 : (window.CONFIG?.SHIPPING?.STANDARD_FEE || 20);
    const total = subtotal + shippingFee;

    const remainingForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);
    const progressPercent = Math.min(100, Math.round((subtotal / freeShippingThreshold) * 100));

    return {
      subtotal,
      shippingFee,
      isFreeShipping,
      total,
      remainingForFreeShipping,
      progressPercent
    };
  },

  updateBadge(animate = false) {
    const totalQuantity = this.items.reduce((sum, i) => sum + i.quantity, 0);
    document.querySelectorAll('.cart-badge-count').forEach(el => {
      el.textContent = totalQuantity;
      if (totalQuantity > 0) {
        el.classList.remove('hidden');
        if (animate) {
          el.classList.remove('bounce');
          void el.offsetWidth; // trigger reflow
          el.classList.add('bounce');
        }
      } else {
        el.classList.add('hidden');
      }
    });
  },

  openDrawer() {
    this.isDrawerOpen = true;
    const drawer = document.getElementById('cart-drawer');
    const overlay = document.getElementById('cart-drawer-overlay');
    if (drawer && overlay) {
      overlay.classList.add('active');
      drawer.classList.add('open');
      this.lockScroll();
    }
  },

  // Hard scroll lock: plain overflow:hidden does not stop the page behind from scrolling on
  // mobile browsers, so pin the body in place and restore the position afterwards.
  lockScroll() {
    if (this._lockY != null) return;
    this._lockY = window.scrollY || document.documentElement.scrollTop || 0;
    const b = document.body;
    b.style.position = 'fixed';
    b.style.top = `-${this._lockY}px`;
    b.style.left = '0';
    b.style.right = '0';
    b.style.width = '100%';
    b.style.overflow = 'hidden';
  },

  unlockScroll() {
    const b = document.body;
    b.style.position = b.style.top = b.style.left = b.style.right = b.style.width = b.style.overflow = '';
    if (this._lockY != null) {
      const y = this._lockY;
      this._lockY = null;
      window.scrollTo(0, y);
    }
  },

  closeDrawer() {
    this.isDrawerOpen = false;
    const drawer = document.getElementById('cart-drawer');
    const overlay = document.getElementById('cart-drawer-overlay');
    if (drawer && overlay) {
      drawer.classList.remove('open');
      overlay.classList.remove('active');
    }
    this.unlockScroll();
  },

  renderDrawer() {
    const listEl = document.getElementById('cart-drawer-items');
    const footerEl = document.getElementById('cart-drawer-footer');
    const emptyEl = document.getElementById('cart-drawer-empty');
    const shippingMeterEl = document.getElementById('cart-drawer-shipping-meter');

    if (!listEl) return;

    if (this.items.length === 0) {
      listEl.innerHTML = '';
      if (emptyEl) emptyEl.style.display = 'flex';
      if (footerEl) footerEl.style.display = 'none';
      if (shippingMeterEl) shippingMeterEl.style.display = 'none';
      return;
    }

    if (emptyEl) emptyEl.style.display = 'none';
    if (footerEl) footerEl.style.display = 'block';
    if (shippingMeterEl) shippingMeterEl.style.display = 'block';

    const totals = this.getTotals();

    // Render Shipping Progress Meter
    if (shippingMeterEl) {
      if (totals.isFreeShipping) {
        shippingMeterEl.innerHTML = `
          <div class="shipping-meter-box free">
            <span class="meter-icon">✨</span>
            <p class="meter-text">You have unlocked <strong>FREE Express Delivery</strong> across the UAE!</p>
          </div>
          <div class="meter-bar-container"><div class="meter-bar-fill" style="width: 100%;"></div></div>
        `;
      } else {
        shippingMeterEl.innerHTML = `
          <div class="shipping-meter-box">
            <span class="meter-icon">🚚</span>
            <p class="meter-text">Add <strong>AED ${totals.remainingForFreeShipping.toFixed(2)}</strong> more for <strong>FREE Delivery</strong></p>
          </div>
          <div class="meter-bar-container"><div class="meter-bar-fill" style="width: ${totals.progressPercent}%;"></div></div>
        `;
      }
    }

    // Render Item Rows
    listEl.innerHTML = this.items.map(item => `
      <div class="cart-drawer-item" data-key="${item.key}">
        <div class="cart-item-image">
          <img src="${item.image}" alt="${item.title}" onerror="this.src='assets/images/banners/hero-campaign.png'">
        </div>
        <div class="cart-item-details">
          <h4 class="cart-item-title"><a href="product.html?id=${item.productId}">${item.title}</a></h4>
          ${(item.size || item.color) ? `<p class="cart-item-variant">${[item.size, item.color].filter(Boolean).join(' · ')}</p>` : ''}
          <div class="cart-item-price">AED ${(item.price * item.quantity).toFixed(2)}</div>
          <div class="cart-item-actions">
            <div class="quantity-control-sm">
              <button type="button" class="qty-btn-minus" onclick="Cart.updateQuantity('${item.key}', ${item.quantity - 1})" aria-label="Decrease quantity">−</button>
              <span class="qty-val">${item.quantity}</span>
              <button type="button" class="qty-btn-plus" onclick="Cart.updateQuantity('${item.key}', ${item.quantity + 1})" aria-label="Increase quantity">+</button>
            </div>
            <button type="button" class="cart-item-remove-btn" onclick="Cart.removeItem('${item.key}')" aria-label="Remove item">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M10 11v6M14 11v6"/></svg>
            </button>
          </div>
        </div>
      </div>
    `).join('');

    // Render Drawer Summary (Clean luxury summary)
    if (footerEl) {
      footerEl.innerHTML = `
        <div class="cart-totals-summary">
          <div class="summary-line">
            <span>Subtotal</span>
            <span>AED ${totals.subtotal.toFixed(2)}</span>
          </div>
          <div class="summary-line">
            <span>UAE Delivery</span>
            <span>${totals.shippingFee === 0 ? '<strong class="gold-text">FREE</strong>' : `AED ${totals.shippingFee.toFixed(2)}`}</span>
          </div>
          <div class="summary-line total">
            <span>Estimated Total</span>
            <span class="total-amount gold-text">AED ${totals.total.toFixed(2)}</span>
          </div>
        </div>
        <div class="cart-drawer-ctas">
          <button type="button" class="btn btn-primary btn-block checkout-btn" onclick="Cart.proceedToCheckout()">
            Proceed to Checkout
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </button>
          <a href="cart.html" class="btn btn-secondary btn-block text-center view-full-cart-link">View Full Bag</a>
        </div>
        <div class="cart-security-badge">
          <span>🔒 100% Encrypted & Verified UAE Payment Gateway</span>
        </div>
      `;
    }
  },

  renderCartPage() {
    const container = document.getElementById('cart-page-container');
    if (!container) return;

    if (this.items.length === 0) {
      container.innerHTML = `
        <div class="empty-cart-state text-center py-24">
          <div class="empty-cart-icon" style="font-size: 3rem; margin-bottom: 1rem;">🛍️</div>
          <h2 class="font-heading text-3xl mb-3">Your shopping bag is empty</h2>
          <p class="text-muted mb-8">Discover our curated UAE collections of signature perfumes, Gulf linen, and everyday luxury.</p>
          <a href="shop.html" class="btn btn-primary px-8 py-3">Explore Collection</a>
        </div>
      `;
      return;
    }

    const totals = this.getTotals();

    container.innerHTML = `
      <div class="cart-page-grid">
        <div class="cart-page-items-col">
          <div class="cart-table-header">
            <span>Product</span>
            <span>Quantity</span>
            <span>Total</span>
          </div>
          <div class="cart-table-rows">
            ${this.items.map(item => `
              <div class="cart-table-row">
                <div class="cart-row-product">
                  <div class="cart-row-thumb">
                    <img src="${item.image}" alt="${item.title}" onerror="this.src='assets/images/banners/hero-campaign.png'">
                  </div>
                  <div class="cart-row-info">
                    <span class="cart-row-brand">${item.category || 'AMICO'}</span>
                    <h3 class="cart-row-title"><a href="product.html?id=${item.productId}">${item.title}</a></h3>
                    ${(item.size || item.color) ? `<p class="cart-row-meta">${[item.size, item.color].filter(Boolean).join(' · ')}</p>` : ''}
                    <span class="cart-row-unit-price">AED ${item.price.toFixed(2)} each</span>
                    <button type="button" class="cart-remove-link" onclick="Cart.removeItem('${item.key}')">Remove</button>
                  </div>
                </div>
                <div class="cart-row-qty">
                  <div class="quantity-control">
                    <button type="button" onclick="Cart.updateQuantity('${item.key}', ${item.quantity - 1})">−</button>
                    <span>${item.quantity}</span>
                    <button type="button" onclick="Cart.updateQuantity('${item.key}', ${item.quantity + 1})">+</button>
                  </div>
                </div>
                <div class="cart-row-total">
                  AED ${(item.price * item.quantity).toFixed(2)}
                </div>
              </div>
            `).join('')}
          </div>
          <div class="cart-page-actions">
            <a href="shop.html" class="btn btn-outline">← Continue Shopping</a>
            <button type="button" onclick="Cart.clear()" class="btn btn-text text-muted">Clear Shopping Bag</button>
          </div>
        </div>

        <div class="cart-page-summary-col">
          <div class="order-summary-card">
            <h3 class="summary-card-title">Order Summary</h3>
            <div class="summary-card-shipping-progress">
              ${totals.isFreeShipping ? `
                <div class="shipping-meter-box free">
                  <span>✨</span>
                  <p>Eligible for <strong>Free Express Delivery</strong> in UAE</p>
                </div>
              ` : `
                <div class="shipping-meter-box">
                  <span>🚚</span>
                  <p>Add <strong>AED ${totals.remainingForFreeShipping.toFixed(2)}</strong> for Free Delivery</p>
                </div>
                <div class="meter-bar-container"><div class="meter-bar-fill" style="width: ${totals.progressPercent}%;"></div></div>
              `}
            </div>
            <div class="summary-line">
              <span>Subtotal (${this.items.reduce((acc, i) => acc + i.quantity, 0)} items)</span>
              <span>AED ${totals.subtotal.toFixed(2)}</span>
            </div>
            <div class="summary-line">
              <span>Standard UAE Shipping</span>
              <span>${totals.shippingFee === 0 ? '<strong class="gold-text">FREE</strong>' : `AED ${totals.shippingFee.toFixed(2)}`}</span>
            </div>
            <div class="summary-divider"></div>
            <div class="summary-line total-large">
              <span>Estimated Total</span>
              <span class="gold-text">AED ${totals.total.toFixed(2)}</span>
            </div>

            <button type="button" onclick="Cart.proceedToCheckout()" class="btn btn-primary btn-block py-4 text-center mt-6">
              Proceed to Shopify Checkout
            </button>

            <a href="${this.getWhatsAppOrderUrl()}" target="_blank" rel="noopener" class="btn btn-whatsapp btn-block text-center mt-3">
              <span>💬 Order via WhatsApp Express</span>
            </a>

            <div class="summary-trust-points">
              <div class="trust-point">✓ 100% Genuine Certified Products</div>
              <div class="trust-point">✓ Same-day & Next-day UAE Delivery with OTP</div>
              <div class="trust-point">✓ Easy 14-Day Returns & Exchanges</div>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  getWhatsAppOrderUrl() {
    const totals = this.getTotals();
    const phone = window.CONFIG?.CONTACT?.PHONE_RAW || '971566353016';
    let text = `Hello AMICO, I would like to place an order:%0A%0A`;
    this.items.forEach((item, idx) => {
      text += `${idx + 1}. *${item.title}*`;
      if (item.size || item.color) text += ` (${[item.size, item.color].filter(Boolean).join('/')})`;
      text += ` x ${item.quantity} = AED ${(item.price * item.quantity).toFixed(2)}%0A`;
    });
    text += `%0A*Estimated Total: AED ${totals.total.toFixed(2)}*%0A%0APlease confirm delivery details.`;
    return `https://wa.me/${phone}?text=${text}`;
  },

  async proceedToCheckout() {
    if (this.items.length === 0) {
      this.showToast('Your shopping bag is empty');
      return;
    }

    const domain = window.CONFIG?.SHOPIFY?.SHOP_DOMAIN || 'amico-online-ae.myshopify.com';

    // If Shopify Storefront API has created a real cart with checkoutUrl, redirect there
    if (window.shopify?.isLiveConfigured) {
      try {
        const lineItems = this.items.map(i => ({
          merchandiseId: i.variantId || i.productId,
          quantity: i.quantity
        }));
        const cart = await window.shopify.cartCreate(lineItems);
        if (cart && cart.checkoutUrl) {
          window.location.href = cart.checkoutUrl;
          return;
        }
      } catch (err) {
        console.warn('Shopify direct checkout redirect fallback:', err.message);
      }
    }

    // Direct redirect to Shopify store domain cart or checkout
    const checkoutUrl = `https://${domain}/cart`;
    this.showToast('Redirecting to secure Shopify checkout...');
    setTimeout(() => {
      window.location.href = checkoutUrl;
    }, 600);
  },

  showToast(message) {
    let toast = document.getElementById('amico-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'amico-toast';
      toast.className = 'amico-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(this._toastTimeout);
    this._toastTimeout = setTimeout(() => {
      toast.classList.remove('show');
    }, 3200);
  },

  bindEvents() {
    // Drawer open triggers
    document.querySelectorAll('[data-cart-trigger]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openDrawer();
      });
    });

    // Drawer close button
    const closeBtn = document.getElementById('cart-drawer-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.closeDrawer());
    }

    // Overlay click
    const overlay = document.getElementById('cart-drawer-overlay');
    if (overlay) {
      overlay.addEventListener('click', () => this.closeDrawer());
    }

    // Keyboard ESC
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isDrawerOpen) {
        this.closeDrawer();
      }
    });
  }
};

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  Cart.init();
});

// Coming back with the browser Back button restores the page from cache with the drawer
// open and scrolling locked. Always reset it.
window.addEventListener('pageshow', () => {
  if (window.Cart) {
    Cart.closeDrawer();
    Cart.loadFromStorage();
    Cart.updateBadge();
    Cart.renderDrawer();
    if (document.getElementById('cart-page-container')) Cart.renderCartPage();
  }
});
// Leaving the page (e.g. tapping "View Full Bag") should never leave scrolling locked.
window.addEventListener('pagehide', () => { Cart.unlockScroll(); });

window.Cart = Cart;
