/**
 * AMICO Online Shop - Main Application Logic & Interactions
 * Sticky navigation, mobile drawer, quick view modal, newsletter, micro-interactions
 */

document.addEventListener('DOMContentLoaded', () => {
  initStickyHeader();
  initMobileNav();
  initQuickViewModal();
  initNewsletterForm();
  initScrollAnimations();
  initBackToTop();
  updateFooterYear();
  highlightActiveNav();
});

/**
 * Sticky Header Transition on Scroll
 */
function initStickyHeader() {
  const header = document.querySelector('.site-header');
  if (!header) return;

  const onScroll = () => {
    if (window.scrollY > 30) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  };

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

/**
 * Mobile Navigation Drawer
 */
function initMobileNav() {
  const toggleBtn = document.querySelector('.mobile-menu-toggle');
  const drawer = document.getElementById('mobile-nav-drawer');
  const overlay = document.getElementById('mobile-nav-overlay');
  const closeBtn = document.getElementById('mobile-nav-close');

  if (!toggleBtn || !drawer) return;

  const openDrawer = () => {
    drawer.classList.add('open');
    if (overlay) overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  };

  const closeDrawer = () => {
    drawer.classList.remove('open');
    if (overlay) overlay.classList.remove('active');
    document.body.style.overflow = '';
  };

  toggleBtn.addEventListener('click', openDrawer);
  if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
  if (overlay) overlay.addEventListener('click', closeDrawer);

  drawer.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', closeDrawer);
  });
}

/**
 * Quick View Modal for Product Cards
 */
function initQuickViewModal() {
  // Ensure Quick View Modal Container exists
  if (!document.getElementById('quick-view-modal')) {
    const modalHTML = `
      <div id="quick-view-overlay" class="modal-overlay" aria-hidden="true"></div>
      <div id="quick-view-modal" class="modal-dialog" role="dialog" aria-modal="true" aria-label="Product Quick View">
        <button type="button" id="quick-view-close" class="modal-close-btn" aria-label="Close dialog">&times;</button>
        <div id="quick-view-body" class="quick-view-content"></div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHTML);
  }

  const modal = document.getElementById('quick-view-modal');
  const overlay = document.getElementById('quick-view-overlay');
  const closeBtn = document.getElementById('quick-view-close');

  const closeModal = () => {
    if (modal && overlay) {
      modal.classList.remove('open');
      overlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  };

  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  if (overlay) overlay.addEventListener('click', closeModal);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal?.classList.contains('open')) {
      closeModal();
    }
  });

  // Global delegate for quick-view buttons
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-quick-view]');
    if (!btn) return;
    e.preventDefault();
    const productId = btn.getAttribute('data-quick-view');
    openQuickView(productId);
  });
}

async function openQuickView(productId) {
  await window.ProductsCatalog?.whenReady();
  const product = window.ProductsCatalog?.findByIdOrHandle(productId);
  if (!product) return;

  const modal = document.getElementById('quick-view-modal');
  const overlay = document.getElementById('quick-view-overlay');
  const body = document.getElementById('quick-view-body');
  if (!modal || !body) return;

  body.innerHTML = `
    <div class="quick-view-grid">
      <div class="quick-view-gallery">
        <img src="${product.image}" alt="${escapeHTML(product.title)}" class="quick-view-main-img" onerror="this.src='assets/images/banners/hero-campaign.png'">
      </div>
      <div class="quick-view-info">
        <span class="product-badge-label">${escapeHTML(product.category)} · ${escapeHTML(product.brand)}</span>
        <h2 class="quick-view-title">${escapeHTML(product.title)}</h2>
        <div class="quick-view-price-row">
          <span class="current-price">${window.ProductsCatalog.priceLabel(product)}</span>
          ${product.compareAtPrice ? `<span class="compare-price">AED ${product.compareAtPrice.toFixed(2)}</span>` : ''}
          ${product.compareAtPrice ? `<span class="discount-pill">${Math.round((1 - product.price / product.compareAtPrice) * 100)}% OFF</span>` : ''}
        </div>
        <p class="quick-view-desc">${escapeHTML(product.description)}</p>
        ${product.fragranceNotes ? `
          <div class="fragrance-notes-pill">
            <strong>Notes:</strong> ${product.fragranceNotes}
          </div>
        ` : ''}

        ${product.sizes?.length ? `
          <div class="option-group">
            <label class="option-label">Select Size:</label>
            <div class="option-buttons-row" id="qv-size-selector">
              ${product.sizes.map((s, idx) => `
                <button type="button" class="option-btn ${idx === 0 ? 'active' : ''}" data-value="${s}">${s}</button>
              `).join('')}
            </div>
          </div>
        ` : ''}

        ${product.colors?.length ? `
          <div class="option-group">
            <label class="option-label">Select Color:</label>
            <div class="option-buttons-row" id="qv-color-selector">
              ${product.colors.map((c, idx) => `
                <button type="button" class="option-btn ${idx === 0 ? 'active' : ''}" data-value="${c}">${c}</button>
              `).join('')}
            </div>
          </div>
        ` : ''}

        <div class="quick-view-actions">
          <div class="quantity-stepper">
            <button type="button" id="qv-qty-minus">−</button>
            <span id="qv-qty-val">1</span>
            <button type="button" id="qv-qty-plus">+</button>
          </div>
          <button type="button" id="qv-add-to-bag-btn" class="btn btn-primary flex-1">
            Add to Bag · AED ${product.price.toFixed(2)}
          </button>
        </div>

        <div class="quick-view-footer-links">
          <a href="product.html?id=${product.id}" class="gold-link">View Full Product Details →</a>
        </div>
      </div>
    </div>
  `;

  let currentQty = 1;
  let selectedSize = product.sizes?.[0] || '';
  let selectedColor = product.colors?.[0] || '';

  // Size click
  body.querySelectorAll('#qv-size-selector .option-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      body.querySelectorAll('#qv-size-selector .option-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedSize = btn.getAttribute('data-value');
    });
  });

  // Color click
  body.querySelectorAll('#qv-color-selector .option-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      body.querySelectorAll('#qv-color-selector .option-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedColor = btn.getAttribute('data-value');
    });
  });

  // Stepper
  const minusBtn = body.querySelector('#qv-qty-minus');
  const plusBtn = body.querySelector('#qv-qty-plus');
  const qtyVal = body.querySelector('#qv-qty-val');
  const addBtn = body.querySelector('#qv-add-to-bag-btn');

  minusBtn?.addEventListener('click', () => {
    if (currentQty > 1) {
      currentQty--;
      qtyVal.textContent = currentQty;
      addBtn.textContent = `Add to Bag · AED ${(product.price * currentQty).toFixed(2)}`;
    }
  });

  plusBtn?.addEventListener('click', () => {
    if (currentQty < product.stock) {
      currentQty++;
      qtyVal.textContent = currentQty;
      addBtn.textContent = `Add to Bag · AED ${(product.price * currentQty).toFixed(2)}`;
    }
  });

  // Add to Bag
  addBtn?.addEventListener('click', () => {
    window.Cart?.addItem({
      productId: product.id,
      variantId: window.ProductsCatalog.resolveVariantId(product, selectedSize, selectedColor),
      title: product.title,
      price: window.ProductsCatalog.resolvePrice(product, selectedSize, selectedColor),
      image: product.image,
      size: selectedSize,
      color: selectedColor,
      category: product.category,
      quantity: currentQty
    });

    // Close quick view modal
    modal.classList.remove('open');
    overlay?.classList.remove('active');
    document.body.style.overflow = '';
  });

  modal.scrollTop = 0;
  overlay?.classList.add('active');
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}

/**
 * Newsletter Form Submission with Real Local Persistence & Validation
 */
function initNewsletterForm() {
  document.querySelectorAll('.newsletter-form').forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailInput = form.querySelector('input[type="email"]');
      if (!emailInput || !emailInput.value.trim()) return;

      const email = emailInput.value.trim().toLowerCase();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        window.Cart?.showToast('Please enter a valid email address');
        return;
      }

      // Save subscriber locally so it persists across sessions
      try {
        const subs = JSON.parse(localStorage.getItem('amico_newsletter_subscribers') || '[]');
        if (!subs.includes(email)) {
          subs.push(email);
          localStorage.setItem('amico_newsletter_subscribers', JSON.stringify(subs));
        }
      } catch (err) {}

      // Swap form with luxury confirmation
      form.innerHTML = `
        <div class="newsletter-success-box">
          <span class="gold-text">✓ Welcome to the AMICO Circle</span>
          <p class="text-xs text-muted mt-1">Thank you for subscribing. We will be in touch with private invitations and seasonal releases.</p>
        </div>
      `;
    });
  });
}

/**
 * Scroll Animations using IntersectionObserver
 */
function initScrollAnimations() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.12,
    rootMargin: '0px 0px -40px 0px'
  });

  document.querySelectorAll('.reveal-on-scroll').forEach(el => {
    observer.observe(el);
  });
}

/**
 * Back to Top Floating Button
 */
function initBackToTop() {
  const btn = document.getElementById('back-to-top-btn');
  if (!btn) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
      btn.classList.add('visible');
    } else {
      btn.classList.remove('visible');
    }
  }, { passive: true });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/**
 * Update dynamic year
 */
function updateFooterYear() {
  document.querySelectorAll('.current-year').forEach(el => {
    el.textContent = new Date().getFullYear();
  });
}

/**
 * Highlight Active Navigation Link
 */
function highlightActiveNav() {
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link, .mobile-nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPath || (currentPath === '' && href === 'index.html')) {
      link.classList.add('active');
    }
  });
}
