/**
 * AMICO Online Shop - Live Search Experience
 * Instant debounced product lookup, search suggestions & modal navigation
 */

const Search = {
  isOpen: false,
  debounceTimer: null,

  init() {
    this.createModalDOM();
    this.bindEvents();
    window.ProductsCatalog?.whenReady();   // load live catalog in the background
  },

  createModalDOM() {
    if (document.getElementById('search-modal')) return;

    const modalHTML = `
      <div id="search-modal-overlay" class="search-modal-overlay" aria-hidden="true"></div>
      <div id="search-modal" class="search-modal" role="dialog" aria-modal="true" aria-label="Product Search">
        <div class="search-modal-container">
          <div class="search-modal-header">
            <div class="search-input-wrapper">
              <svg class="search-icon-svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
              <input type="search" id="global-search-input" class="global-search-input" placeholder="Search perfumes, linen shirts, leather wallets, brands..." autocomplete="off">
              <button type="button" id="search-clear-btn" class="search-clear-btn" aria-label="Clear search" style="display: none;">&times;</button>
            </div>
            <button type="button" id="search-modal-close" class="search-modal-close" aria-label="Close search">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>

          <div class="search-modal-body">
            <!-- Popular Search Queries -->
            <div id="search-suggestions-section" class="search-suggestions-section">
              <p class="search-section-label">Popular Searches</p>
              <div class="search-tags-row">
                <button type="button" class="search-tag-pill" data-query="Abaya">Abaya</button>
                <button type="button" class="search-tag-pill" data-query="Linen Shirt">Linen Shirt</button>
                <button type="button" class="search-tag-pill" data-query="Churidar">Churidar</button>
                <button type="button" class="search-tag-pill" data-query="Urban Style">Urban Style</button>
                <button type="button" class="search-tag-pill" data-query="Frock">Frock</button>
                <button type="button" class="search-tag-pill" data-query="Leather Wallet">Leather Wallet</button>
                <button type="button" class="search-tag-pill" data-query="Candle">Candle</button>
              </div>
            </div>

            <!-- Dynamic Live Results -->
            <div id="search-results-section" class="search-results-section" style="display: none;">
              <div class="search-results-header">
                <p class="search-section-label" id="search-results-count">Results</p>
                <a href="#" id="view-all-results-link" class="view-all-link">View all in Shop →</a>
              </div>
              <div id="search-results-grid" class="search-results-grid"></div>
            </div>

            <!-- Empty State -->
            <div id="search-empty-state" class="search-empty-state" style="display: none;">
              <p class="empty-title">No products found</p>
              <p class="empty-subtitle">Try searching for "Abaya", "Linen", "Frock", or browse all categories.</p>
              <a href="shop.html" class="btn btn-secondary mt-4">Browse All Products</a>
            </div>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHTML);
  },

  bindEvents() {
    // Triggers across the page
    document.querySelectorAll('[data-search-trigger]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.open();
      });
    });

    const closeBtn = document.getElementById('search-modal-close');
    const overlay = document.getElementById('search-modal-overlay');
    const input = document.getElementById('global-search-input');
    const clearBtn = document.getElementById('search-clear-btn');

    if (closeBtn) closeBtn.addEventListener('click', () => this.close());
    if (overlay) overlay.addEventListener('click', () => this.close());

    if (input) {
      input.addEventListener('input', (e) => {
        const val = e.target.value;
        if (clearBtn) clearBtn.style.display = val ? 'block' : 'none';

        clearTimeout(this.debounceTimer);
        this.debounceTimer = setTimeout(() => {
          this.executeSearch(val);
        }, 220);
      });

      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          const q = input.value.trim();
          if (q) {
            window.location.href = `shop.html?q=${encodeURIComponent(q)}`;
          }
        }
      });
    }

    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        if (input) {
          input.value = '';
          input.focus();
        }
        clearBtn.style.display = 'none';
        this.resetSearch();
      });
    }

    // Suggested pills click
    document.querySelectorAll('.search-tag-pill').forEach(pill => {
      pill.addEventListener('click', () => {
        const query = pill.getAttribute('data-query');
        if (input) {
          input.value = query;
          if (clearBtn) clearBtn.style.display = 'block';
          this.executeSearch(query);
        }
      });
    });

    // Keyboard shortcut Cmd+K or Ctrl+K
    document.addEventListener('keydown', (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (this.isOpen) {
          this.close();
        } else {
          this.open();
        }
      }
      if (e.key === 'Escape' && this.isOpen) {
        this.close();
      }
    });
  },

  open() {
    this.isOpen = true;
    const modal = document.getElementById('search-modal');
    const overlay = document.getElementById('search-modal-overlay');
    const input = document.getElementById('global-search-input');

    if (modal && overlay) {
      overlay.classList.add('active');
      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
      setTimeout(() => input?.focus(), 80);
    }
  },

  close() {
    this.isOpen = false;
    const modal = document.getElementById('search-modal');
    const overlay = document.getElementById('search-modal-overlay');

    if (modal && overlay) {
      modal.classList.remove('open');
      overlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  },

  resetSearch() {
    const suggestions = document.getElementById('search-suggestions-section');
    const results = document.getElementById('search-results-section');
    const empty = document.getElementById('search-empty-state');

    if (suggestions) suggestions.style.display = 'block';
    if (results) results.style.display = 'none';
    if (empty) empty.style.display = 'none';
  },

  executeSearch(query) {
    const cleanQuery = (query || '').trim();
    if (!cleanQuery) {
      this.resetSearch();
      return;
    }

    const suggestions = document.getElementById('search-suggestions-section');
    const resultsSection = document.getElementById('search-results-section');
    const resultsGrid = document.getElementById('search-results-grid');
    const resultsCount = document.getElementById('search-results-count');
    const emptyState = document.getElementById('search-empty-state');
    const viewAllLink = document.getElementById('view-all-results-link');

    if (suggestions) suggestions.style.display = 'none';

    const matches = window.ProductsCatalog?.filter({ query: cleanQuery }) || [];

    if (viewAllLink) {
      viewAllLink.href = `shop.html?q=${encodeURIComponent(cleanQuery)}`;
    }

    if (matches.length === 0) {
      if (resultsSection) resultsSection.style.display = 'none';
      if (emptyState) emptyState.style.display = 'block';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';
    if (resultsSection) resultsSection.style.display = 'block';
    if (resultsCount) resultsCount.textContent = `${matches.length} Product${matches.length > 1 ? 's' : ''} Found`;

    if (resultsGrid) {
      resultsGrid.innerHTML = matches.slice(0, 6).map(p => `
        <a href="product.html?id=${p.id}" class="search-result-card">
          <div class="result-thumb">
            <img src="${p.image}" alt="${escapeHTML(p.title)}" onerror="this.src='assets/images/banners/hero-campaign.png'">
          </div>
          <div class="result-info">
            <span class="result-brand">${escapeHTML(p.brand)}</span>
            <h4 class="result-title">${escapeHTML(p.title)}</h4>
            <div class="result-price-row">
              <span class="result-price">${window.ProductsCatalog.priceLabel(p)}</span>
              ${p.compareAtPrice ? `<span class="result-old-price">AED ${p.compareAtPrice.toFixed(2)}</span>` : ''}
            </div>
          </div>
        </a>
      `).join('');
    }
  }
};

document.addEventListener('DOMContentLoaded', () => {
  Search.init();
});

window.Search = Search;
