/**
 * AMICO Online Shop - Products Catalog & Storefront Adapters
 * Supplies verified store data & transforms Shopify Storefront API GraphQL responses
 */

const VERIFIED_PRODUCTS = [
  {
    id: "urban-style-stylish-frock",
    shopifyId: "gid://shopify/Product/8300001",
    currency: "AED",
    stock: 20,
    featured: true,
    rating: 0,
    reviewCount: 0,
    handle: "urban-style-stylish-frock",
    title: "Royal Lora – Stylish Frock",
    brand: "ROYAL LORA",
    category: "Ladies Wear",
    subcategory: "Frocks",
    price: 80.0,
    priceMax: 160.0,
    badge: "New Arrival",
    sizes: [
      "S",
      "M",
      "L",
      "XL"
    ],
    colors: [],
    images: [
      "assets/images/products/urban-style-stylish-frock-01.jpg",
      "assets/images/products/urban-style-stylish-frock-02.jpg",
      "assets/images/products/urban-style-stylish-frock-03.jpg",
      "assets/images/products/urban-style-stylish-frock-04.jpg",
      "assets/images/products/urban-style-stylish-frock-05.jpg",
      "assets/images/products/urban-style-stylish-frock-06.jpg",
      "assets/images/products/urban-style-stylish-frock-07.jpg",
      "assets/images/products/urban-style-stylish-frock-08.jpg",
      "assets/images/products/urban-style-stylish-frock-09.jpg",
      "assets/images/products/urban-style-stylish-frock-10.jpg"
    ],
    description: "Trendy and comfortable, perfect for special occasions.",
    details: [
      "Flattering fit",
      "Premium fabric",
      "Stylish cuts",
      "Sizes: S, M, L, XL"
    ],
    variants: [
      {
        id: "gid://shopify/ProductVariant/8300001-1",
        size: "S",
        price: 80.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300001-2",
        size: "M",
        price: 80.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300001-3",
        size: "L",
        price: 80.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300001-4",
        size: "XL",
        price: 80.0,
        available: true
      }
    ],
    image: "assets/images/products/urban-style-stylish-frock-01.jpg"
  },
  {
    id: "urban-style-modest-abaya",
    shopifyId: "gid://shopify/Product/8300002",
    currency: "AED",
    stock: 20,
    featured: true,
    rating: 0,
    reviewCount: 0,
    handle: "urban-style-modest-abaya",
    title: "Royal Lora – Modest Abaya",
    brand: "ROYAL LORA",
    category: "Ladies Wear",
    subcategory: "Abayas",
    price: 100.0,
    priceMax: 250.0,
    badge: "Modest Wear",
    sizes: [
      "52 in",
      "54 in",
      "56 in",
      "58 in",
      "60 in"
    ],
    colors: [],
    images: [
      "assets/images/products/urban-style-modest-abaya-01.jpg",
      "assets/images/products/urban-style-modest-abaya-02.jpg",
      "assets/images/products/urban-style-modest-abaya-03.jpg",
      "assets/images/products/urban-style-modest-abaya-04.jpg",
      "assets/images/products/urban-style-modest-abaya-05.jpg",
      "assets/images/products/urban-style-modest-abaya-06.jpg",
      "assets/images/products/urban-style-modest-abaya-07.jpg",
      "assets/images/products/urban-style-modest-abaya-08.jpg",
      "assets/images/products/urban-style-modest-abaya-09.jpg",
      "assets/images/products/urban-style-modest-abaya-10.jpg"
    ],
    description: "Graceful and contemporary design ensuring full coverage with elegance.",
    details: [
      "High-quality fabric",
      "Comfortable drape",
      "Sophisticated finish",
      "Standard lengths: 52 to 60 inches"
    ],
    variants: [
      {
        id: "gid://shopify/ProductVariant/8300002-1",
        size: "52 in",
        price: 100.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300002-2",
        size: "54 in",
        price: 100.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300002-3",
        size: "56 in",
        price: 100.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300002-4",
        size: "58 in",
        price: 100.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300002-5",
        size: "60 in",
        price: 100.0,
        available: true
      }
    ],
    image: "assets/images/products/urban-style-modest-abaya-01.jpg"
  },
  {
    id: "urban-style-churidar-set",
    shopifyId: "gid://shopify/Product/8300003",
    currency: "AED",
    stock: 20,
    featured: true,
    rating: 0,
    reviewCount: 0,
    handle: "urban-style-churidar-set",
    title: "Royal Lora – Indian Churidar Set",
    brand: "ROYAL LORA",
    category: "Ladies Wear",
    subcategory: "Churidar Sets",
    price: 75.0,
    priceMax: 150.0,
    badge: "Embroidered",
    sizes: [
      "S",
      "M",
      "L",
      "XL",
      "XXL"
    ],
    colors: [],
    images: [
      "assets/images/products/urban-style-churidar-set-01.jpg",
      "assets/images/products/urban-style-churidar-set-02.jpg",
      "assets/images/products/urban-style-churidar-set-03.jpg",
      "assets/images/products/urban-style-churidar-set-04.jpg",
      "assets/images/products/urban-style-churidar-set-05.jpg",
      "assets/images/products/urban-style-churidar-set-06.jpg",
      "assets/images/products/urban-style-churidar-set-07.jpg",
      "assets/images/products/urban-style-churidar-set-08.jpg"
    ],
    description: "Elegant Indian Churidar sets crafted from soft, breathable fabrics with intricate embroidery. Perfect for daily wear and special occasions.",
    details: [
      "Soft, breathable fabric",
      "Intricate embroidery",
      "Sizes: S to XXL"
    ],
    variants: [
      {
        id: "gid://shopify/ProductVariant/8300003-1",
        size: "S",
        price: 75.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300003-2",
        size: "M",
        price: 75.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300003-3",
        size: "L",
        price: 75.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300003-4",
        size: "XL",
        price: 75.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300003-5",
        size: "XXL",
        price: 75.0,
        available: true
      }
    ],
    image: "assets/images/products/urban-style-churidar-set-01.jpg"
  },
  {
    id: "urban-style-linen-shirt",
    shopifyId: "gid://shopify/Product/8300004",
    currency: "AED",
    stock: 20,
    featured: true,
    rating: 0,
    reviewCount: 0,
    handle: "urban-style-linen-shirt",
    title: "Urban Style Linen Shirt",
    brand: "URBAN STYLE",
    category: "Men's Wear",
    subcategory: "Shirts",
    price: 39.0,
    badge: "Summer Linen",
    sizes: [
      "M",
      "L",
      "XL",
      "XXL"
    ],
    colors: [
      "White",
      "Sky Blue",
      "Pink",
      "Yellow",
      "Olive Green",
      "Navy Blue"
    ],
    images: [
      "assets/images/products/urban-style-linen-shirt-01.jpg",
      "assets/images/products/urban-style-linen-shirt-02.jpg",
      "assets/images/products/urban-style-linen-shirt-03.jpg",
      "assets/images/products/urban-style-linen-shirt-04.jpg",
      "assets/images/products/urban-style-linen-shirt-05.jpg",
      "assets/images/products/urban-style-linen-shirt-06.jpg",
      "assets/images/products/urban-style-linen-shirt-07.jpg",
      "assets/images/products/urban-style-linen-shirt-08.jpg",
      "assets/images/products/urban-style-linen-shirt-09.jpg",
      "assets/images/products/urban-style-linen-shirt-10.jpg"
    ],
    description: "Upgrade your summer wardrobe with Urban Style's premium linen collection. Crafted for ultimate breathability and effortless style, this lightweight shirt keeps you cool and sharp. Available in six versatile colors, sizes M to XXL.",
    details: [
      "Premium linen",
      "Lightweight and breathable",
      "Six colors",
      "Sizes: M, L, XL, XXL"
    ],
    variants: [
      {
        id: "gid://shopify/ProductVariant/8300004-11",
        size: "M",
        color: "White",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-12",
        size: "M",
        color: "Sky Blue",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-13",
        size: "M",
        color: "Pink",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-14",
        size: "M",
        color: "Yellow",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-15",
        size: "M",
        color: "Olive Green",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-16",
        size: "M",
        color: "Navy Blue",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-21",
        size: "L",
        color: "White",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-22",
        size: "L",
        color: "Sky Blue",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-23",
        size: "L",
        color: "Pink",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-24",
        size: "L",
        color: "Yellow",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-25",
        size: "L",
        color: "Olive Green",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-26",
        size: "L",
        color: "Navy Blue",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-31",
        size: "XL",
        color: "White",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-32",
        size: "XL",
        color: "Sky Blue",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-33",
        size: "XL",
        color: "Pink",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-34",
        size: "XL",
        color: "Yellow",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-35",
        size: "XL",
        color: "Olive Green",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-36",
        size: "XL",
        color: "Navy Blue",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-41",
        size: "XXL",
        color: "White",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-42",
        size: "XXL",
        color: "Sky Blue",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-43",
        size: "XXL",
        color: "Pink",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-44",
        size: "XXL",
        color: "Yellow",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-45",
        size: "XXL",
        color: "Olive Green",
        price: 39.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300004-46",
        size: "XXL",
        color: "Navy Blue",
        price: 39.0,
        available: true
      }
    ],
    image: "assets/images/products/urban-style-linen-shirt-01.jpg"
  },
  {
    id: "urban-style-linen-pants",
    shopifyId: "gid://shopify/Product/8300005",
    currency: "AED",
    stock: 20,
    featured: true,
    rating: 0,
    reviewCount: 0,
    handle: "urban-style-linen-pants",
    title: "Urban Style Linen Pants",
    brand: "URBAN STYLE",
    category: "Men's Wear",
    subcategory: "Pants",
    price: 69.0,
    badge: "Summer Linen",
    sizes: [
      "32",
      "34",
      "36",
      "38"
    ],
    colors: [
      "White",
      "Black",
      "Brown",
      "Caramel",
      "Sage Green"
    ],
    images: [
      "assets/images/products/urban-style-linen-pants-01.jpg",
      "assets/images/products/urban-style-linen-pants-02.jpg",
      "assets/images/products/urban-style-linen-pants-03.jpg",
      "assets/images/products/urban-style-linen-pants-04.jpg",
      "assets/images/products/urban-style-linen-pants-05.jpg",
      "assets/images/products/urban-style-linen-pants-06.jpg"
    ],
    description: "Part of Urban Style's premium linen collection. Crafted for ultimate breathability and effortless style, these lightweight pants keep you cool and sharp. Available in five classic tones, waist sizes 32 to 38.",
    details: [
      "Premium linen",
      "Lightweight and breathable",
      "Five classic tones",
      "Sizes: 32 to 38"
    ],
    variants: [
      {
        id: "gid://shopify/ProductVariant/8300005-11",
        size: "32",
        color: "White",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-12",
        size: "32",
        color: "Black",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-13",
        size: "32",
        color: "Brown",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-14",
        size: "32",
        color: "Caramel",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-15",
        size: "32",
        color: "Sage Green",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-21",
        size: "34",
        color: "White",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-22",
        size: "34",
        color: "Black",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-23",
        size: "34",
        color: "Brown",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-24",
        size: "34",
        color: "Caramel",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-25",
        size: "34",
        color: "Sage Green",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-31",
        size: "36",
        color: "White",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-32",
        size: "36",
        color: "Black",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-33",
        size: "36",
        color: "Brown",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-34",
        size: "36",
        color: "Caramel",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-35",
        size: "36",
        color: "Sage Green",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-41",
        size: "38",
        color: "White",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-42",
        size: "38",
        color: "Black",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-43",
        size: "38",
        color: "Brown",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-44",
        size: "38",
        color: "Caramel",
        price: 69.0,
        available: true
      },
      {
        id: "gid://shopify/ProductVariant/8300005-45",
        size: "38",
        color: "Sage Green",
        price: 69.0,
        available: true
      }
    ],
    image: "assets/images/products/urban-style-linen-pants-01.jpg"
  }
];

/* ---------------------------------------------------------------------------
 * MODA CART — Watches, Footwear, Bags
 * Built-in fallback data. When Shopify is connected (see js/config.js) these
 * are replaced by live Shopify data; prices below are PLACEHOLDERS.
 * ------------------------------------------------------------------------- */
const MODACRAFT_PRODUCTS = [
  {
    key: 'vintage-leather-watch', n: 8400001,
    title: 'Moda Cart – Vintage Leather Watch', category: 'Watches', subcategory: 'Leather Strap',
    price: 129, badge: 'New Arrival', featured: true,
    img: ['modacraft-watch-vintage-leather-01'],
    description: 'Elegant timepiece with a layered silver dial and black leather strap. Perfect for daily wear.',
    details: ['Round stainless-style case', 'Black genuine-look leather strap', 'Analog quartz movement']
  },
  {
    key: 'roman-dial-classic-watch', n: 8400002,
    title: 'Moda Cart – Roman Dial Classic Watch', category: 'Watches', subcategory: 'Leather Strap',
    price: 139, badge: 'Best Seller', featured: true,
    img: ['modacraft-watch-roman-dial-01', 'modacraft-watch-roman-dial-02'],
    description: 'A refined cream roman-numeral dial with a brown leather strap. Precision and style for every day.',
    details: ['Roman numeral cream dial', 'Brown leather strap', 'Analog quartz movement']
  },
  {
    key: 'sport-chronograph-watch', n: 8400003,
    title: 'Moda Cart – Sport Chronograph Watch', category: 'Watches', subcategory: 'Sport',
    price: 119, badge: '', featured: false,
    img: ['modacraft-watch-sport-grey-01'],
    description: 'Bold grey sport watch with a chronograph-style dial and soft silicone strap for easy daily wear.',
    details: ['Octagonal case', 'Soft silicone strap', 'Chronograph-style sub-dials']
  },
  {
    key: 'black-chronograph-leather-watch', n: 8400004,
    title: 'Moda Cart – Black Chronograph Leather Watch', category: 'Watches', subcategory: 'Leather Strap',
    price: 149, badge: '', featured: true,
    img: ['modacraft-watch-chrono-black-01'],
    description: 'Dark chronograph dial with date window and a rugged brown leather strap.',
    details: ['Black chronograph dial with date', 'Brown leather strap', 'Analog quartz movement']
  },
  {
    key: 'nylon-loop-watch', n: 8400005,
    title: 'Moda Cart – Nylon Loop Strap Watch', category: 'Watches', subcategory: 'Casual',
    price: 169, badge: 'New Arrival', featured: false,
    img: ['modacraft-watch-smart-loop-01'],
    description: 'Modern round-dial watch with a lightweight woven nylon loop strap. Comfortable all day.',
    details: ['Round dial', 'Woven nylon loop strap', 'Lightweight fit']
  },
  {
    key: 'white-casual-sneakers', n: 8400006,
    title: 'Moda Cart – White Casual Sneakers', category: 'Footwear', subcategory: 'Sneakers',
    price: 99, badge: 'New Arrival', featured: true,
    sizes: ['40', '41', '42', '43', '44'],
    img: ['modacraft-footwear-white-sneaker-01'],
    description: 'Clean white leather-look sneakers with a cushioned sole. Comfortable and trendy for all-day wear.',
    details: ['Soft cushioned insole', 'Durable grip sole', 'Easy lace-up fit']
  },
  {
    key: 'horse-embossed-leather-wallet', n: 8400007,
    title: 'Moda Cart – Horse Embossed Leather Wallet', category: 'Bags', subcategory: 'Wallets',
    price: 59, badge: '', featured: true,
    colors: ['Tan', 'Black'],
    img: ['modacraft-bag-horse-wallet-01'],
    description: 'Slim leather wallet with an embossed horse emblem and multiple card slots.',
    details: ['Multiple card slots', 'Slim pocket-friendly design', 'Available in Tan and Black']
  },
  {
    key: 'slim-two-tone-wallet', n: 8400008,
    title: 'Moda Cart – Slim Two-Tone Wallet', category: 'Bags', subcategory: 'Wallets',
    price: 49, badge: '', featured: false,
    img: ['modacraft-bag-slim-wallet-01'],
    description: 'Compact two-tone blue and beige wallet with a stitched finish. Easy to carry every day.',
    details: ['Compact fold design', 'Stitched two-tone finish', 'Card and cash slots']
  }
];

/** Turn a compact Moda Cart definition into the full product shape. */
function buildModaProduct(d) {
  const images = d.img.map(n => `assets/images/products/${n}.jpg`);
  const variantAxis = d.sizes ? 'size' : (d.colors ? 'color' : null);
  const values = d.sizes || d.colors || [null];
  return {
    id: `moda-cart-${d.key}`,
    shopifyId: `gid://shopify/Product/${d.n}`,
    handle: `moda-cart-${d.key}`,
    currency: 'AED',
    stock: 20,
    featured: d.featured,
    rating: 0,
    reviewCount: 0,
    title: d.title,
    brand: 'MODA CART',
    category: d.category,
    subcategory: d.subcategory,
    price: d.price,
    badge: d.badge,
    sizes: d.sizes || [],
    colors: d.colors || [],
    images,
    image: images[0],
    description: d.description,
    details: d.details,
    variants: values.map((v, i) => ({
      id: `gid://shopify/ProductVariant/${d.n}-${i + 1}`,
      ...(variantAxis ? { [variantAxis]: v } : {}),
      price: d.price,
      available: true
    })),
    source: 'local'
  };
}

MODACRAFT_PRODUCTS.forEach(d => VERIFIED_PRODUCTS.push(buildModaProduct(d)));


/* ---------------------------------------------------------------------------
 * MOUJ PERFUME — fragrances (built-in fallback; Shopify replaces when connected)
 * Photo-to-name matching and the Royal Oud price are placeholders to confirm.
 * ------------------------------------------------------------------------- */
const MOUJ_PRODUCTS = [
  {
    key: 'royal-oud', n: 8500001, title: 'Mouj Perfume – Royal Oud',
    price: 89, size: '', badge: '', featured: true,
    img: ['mouj-royal-oud-01', 'mouj-royal-oud-02', 'mouj-royal-oud-03'],
    profile: 'Deep, woody, and rich oriental scent.',
    feature: 'Delivers a grand and luxurious feel.'
  },
  {
    key: 'al-malaki', n: 8500002, title: 'Mouj Perfume – Al Malaki',
    price: 89, size: '100 ML', badge: '', featured: true,
    img: ['mouj-al-malaki-01', 'mouj-al-malaki-02', 'mouj-al-malaki-03'],
    profile: 'A blend of classic Arabian notes and floral aromas.',
    feature: 'Long-lasting royal experience.'
  },
  {
    key: 'blue-wave', n: 8500003, title: 'Mouj Perfume – Blue Wave',
    price: 90, size: '100 ML', badge: '', featured: true,
    img: ['mouj-blue-wave-01', 'mouj-blue-wave-02'],
    profile: 'Fresh, aquatic, and energetic scent.',
    feature: 'Ideal for daily wear and an instant burst of freshness.'
  },
  {
    key: 'night-gold', n: 8500004, title: 'Mouj Perfume – Night Gold',
    price: 89, size: '100 ML', badge: '', featured: true,
    img: ['mouj-night-gold-01', 'mouj-night-gold-02', 'mouj-night-gold-03'],
    profile: 'Spicy, warm, and luxurious fragrance.',
    feature: 'Perfect for evenings and special gatherings.'
  },
  {
    key: 'velvet-bloom', n: 8500005, title: 'Mouj Perfume – Velvet Bloom',
    price: 89, size: '100 ML', badge: '', featured: false,
    img: ['mouj-velvet-bloom-01', 'mouj-velvet-bloom-02'],
    profile: 'Soft floral and sweet aroma.',
    feature: 'Provides an attractive and romantic feel.'
  }
];

function buildMoujProduct(d) {
  const images = d.img.map(n => `assets/images/products/${n}.jpg`);
  return {
    id: `mouj-${d.key}`,
    shopifyId: `gid://shopify/Product/${d.n}`,
    handle: `mouj-${d.key}`,
    currency: 'AED',
    stock: 20,
    featured: d.featured,
    rating: 0,
    reviewCount: 0,
    title: d.title,
    brand: 'MOUJ PERFUME',
    category: 'Perfumes',
    subcategory: 'Fragrance',
    price: d.price,
    badge: d.badge,
    sizes: [],
    colors: [],
    images,
    image: images[0],
    description: `${d.profile} ${d.feature}`,
    fragranceNotes: d.profile,
    details: [`Fragrance profile: ${d.profile}`, `Special feature: ${d.feature}`, ...(d.size ? [`Size: ${d.size}`] : [])],
    variants: [{ id: `gid://shopify/ProductVariant/${d.n}-1`, price: d.price, available: true }],
    source: 'local'
  };
}

MOUJ_PRODUCTS.forEach(d => VERIFIED_PRODUCTS.push(buildMoujProduct(d)));

/** Escape text from Shopify/catalog data before putting it into HTML templates. */
function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]
  ));
}
if (typeof window !== 'undefined') window.escapeHTML = escapeHTML;

const ProductsCatalog = {
  /** Current product list: live Shopify data when connected, else built-in. */
  _products: [...VERIFIED_PRODUCTS],
  /** 'shopify' | 'local' — where _products came from */
  source: 'local',
  _readyPromise: null,
  _CACHE_KEY: 'amico_catalog_v2',

  /* ------------------------- Shopify live sync --------------------------- */

  /**
   * Resolves once the catalog is loaded. Every page waits on this before
   * rendering products, so prices/images/stock always come from Shopify when
   * it is connected. Safe to call many times (memoised).
   */
  whenReady() {
    if (!this._readyPromise) this._readyPromise = this._load();
    return this._readyPromise.then(() => this);
  },

  async _load() {
    const cfg = (window.CONFIG && window.CONFIG.SHOPIFY) || {};
    const svc = window.shopify;

    if (!svc || !svc.isLiveConfigured) {
      this.source = 'local';
      return;
    }

    // Fresh cache -> no network needed (keeps navigation instant)
    const cached = this._readCache(cfg);
    const maxAge = (cfg.CACHE_SECONDS ?? 60) * 1000;
    if (cached && Date.now() - cached.t < maxAge) {
      this._products = cached.products;
      this.source = 'shopify';
      return;
    }

    try {
      const request = svc.fetchAllProducts().then(list => {
        if (list.length) this._writeCache(cfg, list);
        return list;
      });
      const timeout = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Shopify request timed out')), cfg.FETCH_TIMEOUT_MS || 4500));
      const list = await Promise.race([request, timeout]);

      if (list.length) {
        this._products = list;
        this.source = 'shopify';
        return;
      }
      throw new Error('Shopify returned no products');
    } catch (err) {
      console.warn('Shopify catalog unavailable:', err.message);
      if (cached) {                        // stale cache beats built-in data
        this._products = cached.products;
        this.source = 'shopify';
      } else if (cfg.FALLBACK_TO_VERIFIED_CATALOG === false) {
        this._products = [];
        this.source = 'shopify';
      } else {
        this._products = [...VERIFIED_PRODUCTS];
        this.source = 'local';
      }
    }
  },

  _readCache(cfg) {
    try {
      const raw = sessionStorage.getItem(this._CACHE_KEY);
      if (!raw) return null;
      const data = JSON.parse(raw);
      return data && data.domain === cfg.SHOP_DOMAIN && Array.isArray(data.products) ? data : null;
    } catch (e) { return null; }
  },

  _writeCache(cfg, products) {
    try {
      sessionStorage.setItem(this._CACHE_KEY, JSON.stringify({ t: Date.now(), domain: cfg.SHOP_DOMAIN, products }));
    } catch (e) { /* storage full / blocked: ignore */ }
  },

  /* ----------------------------- queries --------------------------------- */

  getAll() {
    return [...this._products];
  },

  findByIdOrHandle(idOrHandle) {
    if (!idOrHandle) return null;
    return this._products.find(p =>
      p.id === idOrHandle ||
      p.handle === idOrHandle ||
      p.shopifyId === idOrHandle
    ) || null;
  },

  /** Like findByIdOrHandle, but asks Shopify directly if the product isn't in the list. */
  async findOrFetch(idOrHandle) {
    await this.whenReady();
    const hit = this.findByIdOrHandle(idOrHandle);
    if (hit || !window.shopify?.isLiveConfigured || !idOrHandle) return hit;
    try {
      const p = await window.shopify.getProductByHandle(idOrHandle);
      if (p && p.source === 'shopify') this._products.push(p);
      return p;
    } catch (e) { return null; }
  },

  filter({ category, brand, query, minPrice, maxPrice, inStockOnly, sort }) {
    let results = [...this._products];

    if (category && category !== 'all' && category !== 'All Collections') {
      const catLower = category.toLowerCase();
      results = results.filter(p => (p.category || '').toLowerCase() === catLower);
    }

    if (brand && brand !== 'all') {
      const brandLower = brand.toLowerCase();
      results = results.filter(p => (p.brand || '').toLowerCase() === brandLower);
    }

    if (query && query.trim()) {
      const q = query.trim().toLowerCase();
      results = results.filter(p =>
        (p.title || '').toLowerCase().includes(q) ||
        (p.brand || '').toLowerCase().includes(q) ||
        (p.category || '').toLowerCase().includes(q) ||
        (p.subcategory || '').toLowerCase().includes(q) ||
        (p.description || '').toLowerCase().includes(q)
      );
    }

    if (typeof minPrice === 'number') results = results.filter(p => p.price >= minPrice);
    if (typeof maxPrice === 'number') results = results.filter(p => p.price <= maxPrice);
    if (inStockOnly) results = results.filter(p => p.stock > 0);

    switch (sort) {
      case 'price-asc':  results.sort((a, b) => a.price - b.price); break;
      case 'price-desc': results.sort((a, b) => b.price - a.price); break;
      case 'rating':     results.sort((a, b) => b.rating - a.rating); break;
      case 'title-asc':  results.sort((a, b) => a.title.localeCompare(b.title)); break;
      case 'featured':
      default:
        results.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
        break;
    }

    return results;
  },

  /* ------------------- categories, brands, taglines ---------------------- */

  /**
   * Categories for filters/menus: configured ones first (in config order),
   * then any extra product type found in the catalog (e.g. added in Shopify).
   * Only categories that currently contain products are returned.
   */
  getCategories() {
    const configured = (window.CONFIG?.CATEGORIES || []).filter(c => c.id !== 'all');
    const present = new Set(this._products.map(p => p.category).filter(Boolean));
    const list = configured.filter(c => present.has(c.id)).map(c => ({ ...c }));
    present.forEach(name => {
      if (!list.some(c => c.id.toLowerCase() === name.toLowerCase())) {
        list.push({ id: name, name, description: '' });
      }
    });
    return list;
  },

  getBrands() {
    return [...new Set(this._products.map(p => p.brand).filter(Boolean))].sort();
  },

  categoryDescription(name) {
    const hit = (window.CONFIG?.CATEGORIES || []).find(c => c.id.toLowerCase() === String(name).toLowerCase());
    return hit?.description || '';
  },

  /** First product image of a category (so category tiles follow Shopify photos). */
  categoryImage(name) {
    const p = this._products.find(x => (x.category || '').toLowerCase() === String(name).toLowerCase());
    return p ? p.image : '';
  },

  /* ------------------------------ variants -------------------------------- */

  /** Pick the variant matching the chosen size/color (or the first one). */
  resolveVariant(product, size, color) {
    const vs = (product && product.variants) || [];
    const eq = (a, b) => String(a || '').toLowerCase() === String(b || '').toLowerCase();
    return vs.find(v => (!size || eq(v.size, size)) && (!color || eq(v.color, color))) ||
           vs.find(v => v.available) || vs[0] || null;
  },

  /** Real Shopify variant id for the cart (falls back to the product id). */
  resolveVariantId(product, size, color) {
    const v = this.resolveVariant(product, size, color);
    return (v && v.id) || (product && product.shopifyId) || '';
  },

  /** Price of the selected variant (so a Shopify price change reaches the cart). */
  resolvePrice(product, size, color) {
    const v = this.resolveVariant(product, size, color);
    return (v && v.price) || (product && product.price) || 0;
  },

  /* ------------------------------ formatting ------------------------------ */

  priceLabel(p) {
    if (p && p.priceMax && p.priceMax > p.price) {
      return `AED ${p.price.toFixed(2)} – ${p.priceMax.toFixed(2)}`;
    }
    return p ? `AED ${p.price.toFixed(2)}` : '';
  },

  formatPrice(price) {
    if (typeof price !== 'number') return `${CONFIG.CURRENCY} 0.00`;
    return `${CONFIG.CURRENCY} ${price.toFixed(2)}`;
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { VERIFIED_PRODUCTS, ProductsCatalog };
} else {
  window.VERIFIED_PRODUCTS = VERIFIED_PRODUCTS;
  window.ProductsCatalog = ProductsCatalog;
}
