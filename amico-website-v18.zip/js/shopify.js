/**
 * AMICO Online Shop - Shopify Storefront API GraphQL Client
 * Official Cart & Storefront GraphQL API implementation with graceful resilience
 */

/**
 * One GraphQL field set used for both the product list and single product,
 * so the two can never drift apart.
 */
const PRODUCT_FIELDS_FRAGMENT = `
  fragment ProductFields on Product {
    id
    title
    handle
    description
    vendor
    productType
    tags
    availableForSale
    totalInventory
    priceRange {
      minVariantPrice { amount currencyCode }
      maxVariantPrice { amount currencyCode }
    }
    compareAtPriceRange {
      minVariantPrice { amount currencyCode }
    }
    images(first: 10) {
      edges { node { url altText } }
    }
    variants(first: 100) {
      edges {
        node {
          id
          title
          availableForSale
          price { amount currencyCode }
          compareAtPrice { amount currencyCode }
          selectedOptions { name value }
        }
      }
    }
  }
`;

class ShopifyService {
  constructor(config = window.CONFIG?.SHOPIFY) {
    this.shopDomain = config?.SHOP_DOMAIN || 'amico-online-ae.myshopify.com';
    this.storefrontToken = config?.STOREFRONT_ACCESS_TOKEN || '';
    this.apiVersion = config?.API_VERSION || '2024-04';
    this.endpoint = `https://${this.shopDomain}/api/${this.apiVersion}/graphql.json`;
    this.isLiveConfigured = Boolean(this.storefrontToken && this.shopDomain);
  }

  /**
   * Execute raw GraphQL query against Shopify Storefront API
   */
  async graphql(query, variables = {}) {
    if (!this.isLiveConfigured) {
      throw new Error('Shopify Storefront Access Token not configured. Using verified catalog.');
    }

    const response = await fetch(this.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-Shopify-Storefront-Access-Token': this.storefrontToken
      },
      body: JSON.stringify({ query, variables })
    });

    if (!response.ok) {
      throw new Error(`Shopify API HTTP Error ${response.status}: ${response.statusText}`);
    }

    const json = await response.json();
    if (json.errors && json.errors.length > 0) {
      console.warn('Shopify GraphQL Errors:', json.errors);
      throw new Error(json.errors[0].message);
    }

    return json.data;
  }

  /**
   * Fetch EVERY product from Shopify (paged, 100 per request).
   * Throws on failure so the catalog can decide how to fall back.
   */
  async fetchAllProducts() {
    if (!this.isLiveConfigured) {
      throw new Error('Shopify Storefront Access Token not configured. Using verified catalog.');
    }

    const max = window.CONFIG?.SHOPIFY?.MAX_PRODUCTS || 500;
    const gql = `
      query getProducts($first: Int!, $after: String) {
        products(first: $first, after: $after, sortKey: BEST_SELLING) {
          pageInfo { hasNextPage endCursor }
          edges {
            node { ...ProductFields }
          }
        }
      }
      ${PRODUCT_FIELDS_FRAGMENT}
    `;

    const out = [];
    let after = null;
    while (out.length < max) {
      const data = await this.graphql(gql, { first: 100, after });
      const page = data.products;
      page.edges.forEach(e => out.push(this._normalizeProduct(e.node)));
      if (!page.pageInfo.hasNextPage) break;
      after = page.pageInfo.endCursor;
    }
    return out;
  }

  /**
   * Retrieve products list (kept for backwards compatibility)
   */
  async getProducts() {
    try {
      return await this.fetchAllProducts();
    } catch (err) {
      console.warn('Falling back to local verified catalog:', err.message);
      return window.VERIFIED_PRODUCTS || [];
    }
  }

  /**
   * Retrieve single product by handle
   */
  async getProductByHandle(handle) {
    if (!this.isLiveConfigured) {
      return window.ProductsCatalog?.findByIdOrHandle(handle) || null;
    }

    const gql = `
      query getProductByHandle($handle: String!) {
        product(handle: $handle) { ...ProductFields }
      }
      ${PRODUCT_FIELDS_FRAGMENT}
    `;

    try {
      const data = await this.graphql(gql, { handle });
      if (!data.product) return window.ProductsCatalog?.findByIdOrHandle(handle) || null;
      return this._normalizeProduct(data.product);
    } catch (err) {
      console.warn('Fallback product detail:', err.message);
      return window.ProductsCatalog?.findByIdOrHandle(handle) || null;
    }
  }

  /**
   * Official Shopify Storefront Cart API: Create Cart
   */
  async cartCreate(lines = []) {
    if (!this.isLiveConfigured) {
      return this._mockCartResponse(lines);
    }

    const gql = `
      mutation cartCreate($input: CartInput!) {
        cartCreate(input: $input) {
          cart {
            id
            checkoutUrl
            totalQuantity
            cost {
              subtotalAmount {
                amount
                currencyCode
              }
              totalAmount {
                amount
                currencyCode
              }
            }
            lines(first: 50) {
              edges {
                node {
                  id
                  quantity
                  cost {
                    totalAmount {
                      amount
                      currencyCode
                    }
                  }
                  merchandise {
                    ... on ProductVariant {
                      id
                      title
                      product {
                        id
                        title
                        handle
                      }
                      price {
                        amount
                        currencyCode
                      }
                      image {
                        url
                      }
                    }
                  }
                }
              }
            }
          }
          userErrors {
            field
            message
          }
        }
      }
    `;

    const input = {
      lines: lines.map(l => ({ merchandiseId: l.merchandiseId, quantity: l.quantity }))
    };

    const data = await this.graphql(gql, { input });
    if (data?.cartCreate?.userErrors?.length) {
      throw new Error(data.cartCreate.userErrors[0].message);
    }
    return data.cartCreate.cart;
  }

  /**
   * Official Shopify Storefront Cart API: Add Lines
   */
  async cartLinesAdd(cartId, lines) {
    if (!this.isLiveConfigured) {
      return this._mockCartResponse(lines, cartId);
    }

    const gql = `
      mutation cartLinesAdd($cartId: ID!, $lines: [CartLineInput!]!) {
        cartLinesAdd(cartId: $cartId, lines: $lines) {
          cart {
            id
            checkoutUrl
            totalQuantity
            cost {
              subtotalAmount { amount currencyCode }
              totalAmount { amount currencyCode }
            }
            lines(first: 50) {
              edges {
                node {
                  id
                  quantity
                  merchandise {
                    ... on ProductVariant {
                      id
                      title
                      price { amount currencyCode }
                      product { id title handle }
                    }
                  }
                }
              }
            }
          }
          userErrors {
            field
            message
          }
        }
      }
    `;

    const data = await this.graphql(gql, { cartId, lines });
    if (data?.cartLinesAdd?.userErrors?.length) {
      throw new Error(data.cartLinesAdd.userErrors[0].message);
    }
    return data.cartLinesAdd.cart;
  }

  /**
   * Official Shopify Storefront Cart API: Update Line Quantity
   */
  async cartLinesUpdate(cartId, lines) {
    if (!this.isLiveConfigured) {
      return this._mockCartResponse(lines, cartId);
    }

    const gql = `
      mutation cartLinesUpdate($cartId: ID!, $lines: [CartLineUpdateInput!]!) {
        cartLinesUpdate(cartId: $cartId, lines: $lines) {
          cart {
            id
            checkoutUrl
            totalQuantity
            cost {
              subtotalAmount { amount currencyCode }
              totalAmount { amount currencyCode }
            }
          }
          userErrors {
            field
            message
          }
        }
      }
    `;

    const data = await this.graphql(gql, { cartId, lines });
    return data?.cartLinesUpdate?.cart;
  }

  /**
   * Official Shopify Storefront Cart API: Remove Lines
   */
  async cartLinesRemove(cartId, lineIds) {
    if (!this.isLiveConfigured) {
      return this._mockCartResponse([], cartId);
    }

    const gql = `
      mutation cartLinesRemove($cartId: ID!, $lineIds: [ID!]!) {
        cartLinesRemove(cartId: $cartId, lineIds: $lineIds) {
          cart {
            id
            checkoutUrl
            totalQuantity
            cost {
              subtotalAmount { amount currencyCode }
              totalAmount { amount currencyCode }
            }
          }
          userErrors {
            field
            message
          }
        }
      }
    `;

    const data = await this.graphql(gql, { cartId, lineIds });
    return data?.cartLinesRemove?.cart;
  }

  /**
   * Customer Authentication & Profile API
   */
  async customerLogin(email, password) {
    if (!this.isLiveConfigured) {
      return { token: 'mock_token_' + Date.now(), customer: { email, firstName: 'AMICO VIP Client' } };
    }
    const gql = `
      mutation customerAccessTokenCreate($input: CustomerAccessTokenCreateInput!) {
        customerAccessTokenCreate(input: $input) {
          customerAccessToken {
            accessToken
            expiresAt
          }
          customerUserErrors {
            code
            field
            message
          }
        }
      }
    `;
    const data = await this.graphql(gql, { input: { email, password } });
    if (data?.customerAccessTokenCreate?.customerUserErrors?.length) {
      throw new Error(data.customerAccessTokenCreate.customerUserErrors[0].message);
    }
    return data.customerAccessTokenCreate.customerAccessToken;
  }

  async getCustomerOrders(accessToken) {
    if (!this.isLiveConfigured) {
      return [];
    }
    const gql = `
      query getCustomer($token: String!) {
        customer(customerAccessToken: $token) {
          id
          firstName
          lastName
          email
          phone
          orders(first: 20) {
            edges {
              node {
                id
                name
                orderNumber
                processedAt
                financialStatus
                fulfillmentStatus
                totalPrice {
                  amount
                  currencyCode
                }
                successfulFulfillments(first: 5) {
                  trackingInfo(first: 5) {
                    number
                    url
                  }
                }
                lineItems(first: 20) {
                  edges {
                    node {
                      title
                      quantity
                      variant {
                        price { amount currencyCode }
                        image { url }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    `;
    const data = await this.graphql(gql, { token: accessToken });
    return data?.customer?.orders?.edges?.map(e => e.node) || [];
  }

  /**
   * Helper: Normalize raw Shopify GraphQL node to the shape the site uses.
   * Everything the storefront shows (price, compare-at price, images, stock,
   * sizes/colors, category, brand) comes from here, i.e. from Shopify.
   */
  _normalizeProduct(node) {
    const cfg = window.CONFIG?.SHOPIFY || {};
    const aliases = cfg.CATEGORY_ALIASES || {};
    const tags = (node.tags || []).map(t => String(t));
    const num = v => parseFloat(v || '0') || 0;

    const rawVariants = node.variants?.edges?.map(e => e.node) || [];
    const minPrice = num(node.priceRange?.minVariantPrice?.amount);
    const maxPrice = num(node.priceRange?.maxVariantPrice?.amount);
    const comparePrice = num(node.compareAtPriceRange?.minVariantPrice?.amount);

    const optionValue = (v, re) =>
      (v.selectedOptions || []).find(o => re.test(o.name))?.value || '';

    const variants = rawVariants.map(v => ({
      id: v.id,
      title: v.title,
      size: optionValue(v, /size/i),
      color: optionValue(v, /colou?r/i),
      price: num(v.price?.amount) || minPrice,
      compareAtPrice: num(v.compareAtPrice?.amount),
      available: v.availableForSale !== false,
      selectedOptions: v.selectedOptions || []
    }));

    const uniq = arr => [...new Set(arr.filter(Boolean))];
    const sizes = uniq(variants.map(v => v.size));
    const colors = uniq(variants.map(v => v.color));

    const images = (node.images?.edges || []).map(e => e.node.url);
    const anyAvailable = variants.length ? variants.some(v => v.available) : node.availableForSale !== false;
    let stock = 0;
    if (anyAvailable) {
      stock = (typeof node.totalInventory === 'number' && node.totalInventory > 0) ? node.totalInventory : 20;
    }

    const typeKey = String(node.productType || '').trim().toLowerCase();
    const category = aliases[typeKey] || (node.productType ? node.productType.trim() : 'Fashion');

    const tagValue = prefix => {
      const t = tags.find(x => x.toLowerCase().startsWith(prefix));
      return t ? t.slice(prefix.length).trim() : '';
    };
    const compareAt = comparePrice > minPrice ? comparePrice : null;
    const badge = tagValue('badge:') || (compareAt ? 'Sale' : '');

    return {
      id: node.handle,
      shopifyId: node.id,
      handle: node.handle,
      title: node.title,
      brand: String(node.vendor || 'AMICO').toUpperCase(),
      category,
      subcategory: tagValue('sub:'),
      price: minPrice,
      priceMax: maxPrice > minPrice ? maxPrice : null,
      compareAtPrice: compareAt,
      currency: node.priceRange?.minVariantPrice?.currencyCode || 'AED',
      stock,
      rating: 0,
      reviewCount: 0,
      featured: tags.some(t => t.toLowerCase() === 'featured'),
      badge,
      fragranceNotes: tagValue('notes:'),
      sizes,
      colors,
      image: images[0] || 'assets/images/banners/hero-campaign.png',
      images,
      description: node.description || '',
      variants,
      details: [
        `Brand: ${node.vendor || 'AMICO'}`,
        'Fast delivery across all Emirates',
        '100% Guaranteed Authentic'
      ],
      source: 'shopify'
    };
  }

  /**
   * Mock Cart response for seamless offline/dev testing before store owner supplies token
   */
  _mockCartResponse(lines = [], existingId) {
    const cartId = existingId || 'cart_' + Math.random().toString(36).substring(2, 10);
    return {
      id: cartId,
      checkoutUrl: `https://${this.shopDomain}/cart`,
      totalQuantity: lines.reduce((acc, l) => acc + (l.quantity || 1), 0),
      cost: {
        subtotalAmount: { amount: '0.00', currencyCode: 'AED' },
        totalAmount: { amount: '0.00', currencyCode: 'AED' }
      }
    };
  }
}

// Instantiate and attach globally
const shopify = new ShopifyService();
if (typeof module !== 'undefined' && module.exports) {
  module.exports = shopify;
} else {
  window.shopify = shopify;
}
