# Connect Shopify (5 minutes)

Once connected, **everything the shop shows comes from Shopify**: products, prices,
compare-at (sale) prices, photos, stock, sizes/colours and categories. Change a price or
photo in Shopify admin and the site shows it on the next page load (within 60 seconds).
No code change, no redeploy.

## 1. Get a Storefront API token
Shopify admin -> Settings -> Apps and sales channels -> Develop apps -> Create an app ->
Configure Storefront API scopes, tick:

- `unauthenticated_read_product_listings`
- `unauthenticated_read_product_inventory`
- `unauthenticated_read_product_tags`
- `unauthenticated_read_checkouts` and `unauthenticated_write_checkouts` (cart + checkout)

Install the app, then copy the **Storefront API access token** (it is public-safe).

## 2. Put it in `js/config.js`
```js
SHOPIFY: {
  SHOP_DOMAIN: 'your-store.myshopify.com',
  STOREFRONT_ACCESS_TOKEN: 'paste-token-here',
  ...
}
```

## 3. Set up each product in Shopify
| Shopify field | What it controls on the site |
|---|---|
| **Product type** = `Watches`, `Footwear`, `Bags`, `Perfumes`, `Ladies Wear` or `Men's Wear` | Category pill + the category tagline (taglines live in `CATEGORIES` in `js/config.js`) |
| **Vendor** = `Moda Cart`, `Mouj Perfume`, `Royal Lora` (ladies wear) or `Urban Style` (men's linen) | Brand filter, Brands page |
| **Price / Compare-at price** | Price, strikethrough price, "% OFF" |
| **Media** | Product photos (first image = card image; home category tile uses the first product's image) |
| **Options** named `Size` / `Color` | Size and colour pickers (each variant has its own price + stock) |
| **Inventory / availability** | In stock / Out of stock, quantity limit |
| Tag `featured` | Shown first on the home page |
| Tag `badge:New Arrival` | Badge on the card |
| Tag `notes:Deep, woody...` (perfumes) | "Fragrance profile" box on the product page (use no commas inside the tag) |

Important: make sure every product is **available to the sales channel of the app** (Product
page -> Sales channels). Products that are not published there are not returned by the API.

New product types you add in Shopify (e.g. `Sunglasses`) appear automatically as a new category
pill. To give it a tagline, add an entry to `CATEGORIES` in `js/config.js`.

## Notes
- If Shopify is unreachable, or the token is empty, the site falls back to the built-in catalog.
- Bags, watches and footwear in the built-in catalog use **placeholder prices**; Shopify replaces them.
- Speed vs freshness: `CACHE_SECONDS` in `js/config.js` (default 60).
