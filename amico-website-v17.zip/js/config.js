/**
 * AMICO Online Shop - Core Configuration
 * Production-ready luxury UAE e-commerce platform
 */

const CONFIG = {
  // Store Branding & Identity
  STORE_NAME: 'AMICO Online Shop',
  STORE_TAGLINE: 'Discover Your Style. Experience AMICO.',
  STORE_URL: 'https://amicoonline.ae',
  CURRENCY: 'AED',
  CURRENCY_SYMBOL: 'AED ',
  LOCALE: 'en-AE',

  // Client Business & Contact Information (Verified from UAE Headquarters)
  CONTACT: {
    PHONE: '+971 56 635 3016',
    PHONE_RAW: '971566353016',
    WHATSAPP: 'https://wa.me/971566353016',
    EMAIL: 'gulfcartuae@gmail.com',
    ADDRESS: 'Ajman Free Zone, United Arab Emirates',
    HOURS: 'Saturday – Thursday: 9:00 AM – 9:00 PM GST',
    INSTAGRAM: 'https://instagram.com/amico_ae',
    FACEBOOK: 'https://facebook.com/amicoonlineae',
    TIKTOK: 'https://tiktok.com/@amico_ae'
  },

  // Shopify Storefront API Configuration
  // ---------------------------------------------------------------------
  // Fill SHOP_DOMAIN and STOREFRONT_ACCESS_TOKEN and the whole site becomes
  // Shopify-driven: products, prices, compare-at prices, images, stock,
  // variants and categories are read live from Shopify on every page load.
  // Change a price or photo in Shopify admin -> the site shows it on the
  // next load (within CACHE_SECONDS). No code change, no redeploy.
  // Leave the token empty to keep running on the built-in catalog.
  // See SHOPIFY-SETUP.md for the 5-minute setup.
  SHOPIFY: {
    // e.g. 'amico-online-ae.myshopify.com'
    SHOP_DOMAIN: window.AMICO_SHOPIFY_DOMAIN || 'amico-online-ae.myshopify.com',
    // Public Storefront API access token (safe to expose in frontend code)
    STOREFRONT_ACCESS_TOKEN: window.AMICO_SHOPIFY_TOKEN || '',
    API_VERSION: '2024-04',
    // Use the built-in catalog if Shopify is unreachable / not configured
    FALLBACK_TO_VERIFIED_CATALOG: true,
    // How long (seconds) a fetched catalog is reused before asking Shopify
    // again. Lower = faster price/image updates, higher = fewer API calls.
    CACHE_SECONDS: 60,
    // Max wait (ms) for Shopify before showing the cached/built-in catalog
    FETCH_TIMEOUT_MS: 4500,
    // Max products pulled from Shopify (paged, 100 per request)
    MAX_PRODUCTS: 500,
    // Shopify "Product type" values -> site category names.
    // Matching is case-insensitive; unknown types are shown as their own category.
    CATEGORY_ALIASES: {
      'watch': 'Watches',
      'watches': 'Watches',
      'footwear': 'Footwear',
      'shoes': 'Footwear',
      'shoe': 'Footwear',
      'sneakers': 'Footwear',
      'bag': 'Bags',
      'bags': 'Bags',
      'wallet': 'Bags',
      'wallets': 'Bags',
      'perfume': 'Perfumes',
      'perfumes': 'Perfumes',
      'fragrance': 'Perfumes',
      'fragrances': 'Perfumes',
      'handbags': 'Bags',
      'ladies wear': 'Ladies Wear',
      "men's wear": "Men's Wear",
      'mens wear': "Men's Wear"
    }
  },

  // Verified Delivery & UAE Shipping Policy
  SHIPPING: {
    FREE_SHIPPING_THRESHOLD: 250, // AED
    STANDARD_FEE: 20, // AED
    EXPRESS_FEE: 35, // AED
    ESTIMATED_STANDARD: '1 - 2 Business Days',
    ESTIMATED_EXPRESS: 'Same-Day Express in Dubai, Sharjah & Ajman'
  },

  // Verified Active Coupons & Promotions
  PROMOTIONS: [
    {
      code: 'LINEN20',
      discountPct: 20,
      description: '20% off Urban Style linen shirts & pants',
      category: "Men's Wear",
      validTill: '2026-12-31'
    },
    {
      code: 'MOUJ15',
      discountPct: 15,
      description: '15% off signature Mouj perfumes & pure oud attars',
      category: 'Perfumes',
      validTill: '2026-12-31'
    }
  ],

  // Verified Brands List
  BRANDS: [
    {
      id: 'mouj-perfume',
      name: 'MOUJ PERFUME',
      tagline: 'Signature Arabian luxury fragrances',
      description: 'Mouj Perfume blends rare aged oud, amber, and Taif rose into signature luxury fragrances rooted in Arabian artistry.',
      categories: 'Fragrance • Luxury',
      featured: true,
      initial: 'M'
    },
    {
      id: 'urban-style',
      name: 'URBAN STYLE',
      tagline: 'Premium linen for men',
      description: 'Urban Style offers premium breathable linen shirts and pants for him.',
      categories: 'Fashion • Lifestyle',
      featured: true,
      initial: 'U'
    },
    {
      id: 'moda-cart',
      name: 'MODA CART',
      tagline: 'Watches, footwear & bags',
      description: 'Moda Cart delivers elegant watches, comfortable footwear and chic bags - handpicked staples for the modern metropolitan lifestyle.',
      categories: 'Watches • Footwear • Bags',
      featured: true,
      initial: 'M'
    },
    {
      id: 'royal-lora',
      name: 'ROYAL LORA',
      tagline: 'Ladies wear: abayas, frocks & churidar sets',
      description: 'Royal Lora offers modest abayas, stylish frocks and embroidered churidar sets for her.',
      categories: 'Ladies Wear • Modest • Premium',
      featured: true,
      initial: 'R'
    }
  ],

  // Store Categories (order = order of the shop filter pills).
  // Categories found in Shopify but not listed here are appended automatically.
  CATEGORIES: [
    { id: 'all', name: 'All Products', icon: 'sparkles' },
    { id: 'Watches', name: 'Watches', icon: 'watch',
      description: 'Elegant timepieces combining precision and style. Perfect for daily wear.' },
    { id: 'Footwear', name: 'Footwear', icon: 'shoe',
      description: 'Comfortable and trendy footwear designed for all-day wear.' },
    { id: 'Bags', name: 'Bags', icon: 'bag',
      description: 'Chic and spacious bags to complement your outfit.' },
    { id: 'Perfumes', name: 'Perfumes', icon: 'perfume',
      description: '' },
    { id: 'Ladies Wear', name: 'Ladies Wear', icon: 'shirt',
      description: 'Modest abayas, frocks and churidar sets from Royal Lora.' },
    { id: "Men's Wear", name: "Men's Linen", icon: 'shirt',
      description: 'Premium breathable linen shirts and pants from Urban Style.' }
  ]
};

// Freeze configuration to prevent tampering
if (typeof Object.freeze === 'function') {
  Object.freeze(CONFIG);
}

// Export for module or global use
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CONFIG;
} else {
  window.CONFIG = CONFIG;
}
